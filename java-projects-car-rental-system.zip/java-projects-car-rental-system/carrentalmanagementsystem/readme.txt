the admin username and password is in a file called password.txt
username:admin
password:123456